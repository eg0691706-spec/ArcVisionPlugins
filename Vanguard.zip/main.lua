require "import"
import "java.io.File"

local context = activity or service
local basePath = nil
local idFileName = "vanguard.id"
local nombreCarpetaOriginal = "Auto limpiador de caché vanguard - Visión accesible"
local possibleBases = {
    "/storage/emulated/0/解说/Plugins/",
    "/storage/emulated/0/解说/Complementos/"
}

for _, base in ipairs(possibleBases) do
    local baseDir = File(base)
    if baseDir.exists() and baseDir.isDirectory() then
        local subDirs = baseDir.listFiles()
        if subDirs then
            for i = 0, #subDirs - 1 do
                local subDir = subDirs[i]
                if subDir and subDir.isDirectory() then
                    if File(subDir, idFileName).exists() then
                        basePath = subDir.getAbsolutePath()
                        break
                    end
                end
            end
        end
    end
    if basePath then break end
end

if not basePath then
    for _, base in ipairs(possibleBases) do
        local testPath = base .. nombreCarpetaOriginal
        if File(testPath).exists() then
            basePath = testPath
            io.open(basePath .. "/" .. idFileName, "w"):close()
            break
        end
    end
end

if not basePath then
    basePath = possibleBases[1] .. nombreCarpetaOriginal
    File(basePath).mkdirs()
    io.open(basePath .. "/" .. idFileName, "w"):close()
end

package.path = basePath .. "/?.lua;" .. package.path
local moduleName = "auto_cleaner"
local modulePath = basePath .. "/" .. moduleName .. ".lua"

local function bit_xor(a, b)
    local r = 0
    local p = 1
    for i = 0, 7 do
        local ra = a % 2
        local rb = b % 2
        if ra ~= rb then r = r + p end
        a = (a - ra) / 2
        b = (b - rb) / 2
        p = p * 2
    end
    return r
end

local function xor_bytes(data, key)
    local out = {}
    for i = 1, #data do
        out[i] = string.char(bit_xor(data:byte(i), key))
    end
    return table.concat(out)
end

local function ofuscar(texto)
    local func1, err1 = load(texto)
    if not func1 then return nil, "[C1] Error: "..tostring(err1) end
    local capa1 = string.dump(func1, true)
    local bytecode_invertido = capa1:reverse()
    local wrapper2 = string.format([[
return function()
local reversed_bc = %q
local success, loader = pcall(function()
return load(reversed_bc:reverse())
end)
if not success then error("Capa2: "..tostring(loader)) end
return loader()
end
]], bytecode_invertido)
    local func2, err2 = load(wrapper2, "Capa2", "bt", _G)
    if not func2 then return nil, "[C2] Error: "..tostring(err2) end
    local capa2 = string.dump(func2(), true)
    math.randomseed(os.time() + os.clock() * 1e6)
    local clave = math.random(1, 255)
    local bytecode_xor = xor_bytes(capa2, clave)
    local wrapper3 = string.format([[
return function()
local function bit_xor(a,b)
local r=0 local p=1
for i=0,7 do
local ra=a%%2 local rb=b%%2
if ra~=rb then r=r+p end
a=(a-ra)/2 b=(b-rb)/2 p=p*2
end
return r
end
local clave = %d
local cifrado = %q
local decodificado = cifrado:gsub(".", function(c)
return string.char(bit_xor(c:byte(), clave))
end)
local success, loader = pcall(load, decodificado)
if not success then error("Capa3: "..tostring(loader)) end
return loader()
end
]], clave, bytecode_xor)
    local func3, err3 = load(wrapper3, "Capa3", "bt", _G)
    if not func3 then return nil, "[C3] Error: "..tostring(err3) end
    return string.dump(func3(), true)
end

local code = [[
local M = {}
require "import"
import "android.content.Context"
import "android.content.Intent"
import "android.net.Uri"
import "android.os.AsyncTask"
import "android.os.Handler"
import "android.os.Looper"
import "android.widget.*"
import "android.view.View"
import "android.graphics.Color"
import "java.util.ArrayList"
import "com.androlua.LuaDialog"

local context = activity or service
local pluginPath = "]] .. basePath .. [["

local function runOnUiThread(action)
    local handler = Handler(Looper.getMainLooper())
    handler.post(luajava.createProxy("java.lang.Runnable", { run = action }))
end

-- =========================================================
-- MOTOR DE ACTUALIZACIONES AUTOMÁTICAS (JSON + ZIP)
-- =========================================================
local Http = luajava.bindClass("com.androlua.Http")
local LuaDialog = luajava.bindClass("com.androlua.LuaDialog")
local FileInputStream = luajava.bindClass("java.io.FileInputStream")
local FileOutputStream = luajava.bindClass("java.io.FileOutputStream")
local ZipInputStream = luajava.bindClass("java.util.zip.ZipInputStream")
local json = require("cjson")

-- VERSIÓN ACTUAL DEL CÓDIGO
local CURRENT_VERSION = 1.5
local VERSION_URL = "https://raw.githubusercontent.com/eg0691706-spec/ArcVisionPlugins/main/version.json"

local function unzip(zipFile, targetDir)
    local buffer = byte[1024]
    local zis = ZipInputStream(FileInputStream(zipFile))
    local entry = zis.getNextEntry()
    while entry do
        local fileName = entry.getName()
        local newFile = File(targetDir, fileName)
        if entry.isDirectory() then
            newFile.mkdirs()
        else
            newFile.getParentFile().mkdirs()
            local fos = FileOutputStream(newFile)
            local len = zis.read(buffer)
            while len > 0 do
                fos.write(buffer, 0, len)
                len = zis.read(buffer)
            end
            fos.close()
        end
        entry = zis.getNextEntry()
    end
    zis.closeEntry()
    zis.close()
end

local function startUpdate(zipUrl)
    service.asyncSpeak("Descargando actualización...")
    local downloadPath = pluginPath .. "/update_temp.zip"
    
    -- Añadir marca de tiempo para evitar caché al descargar el ZIP
    local safeZipUrl = zipUrl .. "?t=" .. tostring(os.time())
    
    Http.download(safeZipUrl, downloadPath, function(result)
        if result and File(downloadPath).exists() then
            service.asyncSpeak("Instalando...")
            task(50, function()
                local success, err = pcall(function()
                    unzip(downloadPath, pluginPath)
                    File(downloadPath).delete()
                end)
                if success then
                    service.asyncSpeak("¡Actualizado con éxito! Cierra y vuelve a abrir el complemento.")
                else
                    service.asyncSpeak("Error al instalar: " .. tostring(err))
                end
            end)
        else
            service.asyncSpeak("Error al descargar el archivo.")
        end
    end)
end

local function checkUpdate()
    -- ANTI-CACHÉ: Forzamos a GitHub a darnos la última versión real
    local noCacheUrl = VERSION_URL .. "?t=" .. tostring(os.time())
    
    Http.get(noCacheUrl, function(code, body)
        if code == 200 and body then
            local success, data = pcall(json.decode, body)
            if success and data then
                local remoteVersion = tonumber(data.version)
                if remoteVersion and remoteVersion > CURRENT_VERSION then
                    runOnUiThread(function()
                        local dlgUpdate = LuaDialog(context)
                        dlgUpdate.setTitle("Nueva versión: " .. remoteVersion)
                        dlgUpdate.setMessage("Novedades:\n" .. (data.changelog or "Actualización disponible") .. "\n\n¿Actualizar ahora?")
                        dlgUpdate.setPositiveButton("Sí", function() startUpdate(data.url) end)
                        dlgUpdate.setNegativeButton("No", nil)
                        dlgUpdate.show()
                    end)
                end
            end
        end
    end)
end
-- =========================================================

local MediaPlayer = luajava.bindClass("android.media.MediaPlayer")
local File = luajava.bindClass("java.io.File")
local globalPlayer = nil
local loopPlayer = nil

local function reproducirSonido(nombreArchivo)
    local rutaCompleta = pluginPath .. "/" .. nombreArchivo
    if not File(rutaCompleta).exists() then return end
    if globalPlayer then
        pcall(function()
            globalPlayer.stop()
            globalPlayer.release()
        end)
        globalPlayer = nil
    end
    pcall(function()
        globalPlayer = MediaPlayer()
        globalPlayer.setDataSource(rutaCompleta)
        globalPlayer.prepare()
        globalPlayer.start()
        globalPlayer.setOnCompletionListener(luajava.createProxy("android.media.MediaPlayer$OnCompletionListener", {
            onCompletion = function(mp)
                mp.release()
                globalPlayer = nil
            end
        }))
    end)
end

local function iniciarBucle(nombreArchivo)
    local rutaCompleta = pluginPath .. "/" .. nombreArchivo
    if not File(rutaCompleta).exists() then return end
    if loopPlayer then
        pcall(function()
            loopPlayer.stop()
            loopPlayer.release()
        end)
        loopPlayer = nil
    end
    pcall(function()
        loopPlayer = MediaPlayer()
        loopPlayer.setDataSource(rutaCompleta)
        loopPlayer.setLooping(true)
        loopPlayer.prepare()
        loopPlayer.start()
    end)
end

local function detenerBucle()
    if loopPlayer then
        pcall(function()
            loopPlayer.stop()
            loopPlayer.release()
        end)
        loopPlayer = nil
    end
end

local function buscarYPresionar(target, maxIntentos, labelID, callback)
    local function intento(restantes)
        local botones = {target}
        if service.click(botones) then
            callback(true)
        elseif restantes > 0 then
            local hizoScroll = false
            pcall(function()
                local lista = service.findListView()
                if lista then
                    service.scrollForward(lista)
                    hizoScroll = true
                end
            end)
            if not hizoScroll then
                pcall(function()
                    local w = service.getDisplayWidth()
                    local h = service.getDisplayHeight()
                    service.swipe(math.floor(w/2), math.floor(h*0.8), math.floor(w/2), math.floor(h*0.2), 600)
                end)
            end
            service.postExecute(1200, labelID .. "_retry_" .. restantes, nil, function()
                intento(restantes - 1)
            end)
        else
            callback(false)
        end
    end
    intento(maxIntentos)
end

local function executeAutoClicker(onDone)
    service.postExecute(2500, "inicio_almacenamiento", nil, function()
        service.asyncSpeak("Buscando")
        buscarYPresionar("*Almacenamiento*|*Storage*|*Memoria*", 5, "scroll_almacen", function(encontroAlmac)
            if encontroAlmac then
                service.postExecute(2000, "inicio_cache", nil, function()
                    service.asyncSpeak("Buscando")
                    buscarYPresionar("*caché*|*cache*", 4, "scroll_cache", function(encontroCache)
                        if encontroCache then
                            service.asyncSpeak("Caché limpiada.")
                        else
                            service.asyncSpeak("No se encontró el botón de caché.")
                        end
                        if onDone then onDone() end
                    end)
                end)
            else
                service.asyncSpeak("Almacenamiento no encontrado.")
                if onDone then onDone() end
            end
        end)
    end)
end

local function openAppInfo(pkgName, onDone)
    local Intent = luajava.bindClass("android.content.Intent")
    local Uri = luajava.bindClass("android.net.Uri")
    local intent = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
    intent.setData(Uri.parse("package:" .. pkgName))
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    intent.addFlags(32768)
    local status, err = pcall(function()
        context.startActivity(intent)
    end)
    if status then
        executeAutoClicker(onDone)
    else
        service.asyncSpeak("Error al abrir información de la aplicación.")
        if onDone then onDone() end
    end
end

local queue = {}
local function processQueue()
    if #queue == 0 then
        reproducirSonido("Task finished.mp3")
        service.asyncSpeak("Limpieza finalizada. Volviendo al inicio.")
        service.postExecute(1500, "ir_inicio", nil, function()
            service.toHome()
        end)
        return
    end
    local currentApp = table.remove(queue, 1)
    service.asyncSpeak("Procesando " .. currentApp.name)
    openAppInfo(currentApp.pkg, processQueue)
end

local function openUrl(url)
    local Intent = luajava.bindClass("android.content.Intent")
    local Uri = luajava.bindClass("android.net.Uri")
    local intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    pcall(function() context.startActivity(intent) end)
end

local function showAboutUI(mainDlg)
    local aboutLayout = {
        LinearLayout, orientation = 1, layout_width = "fill", layout_height = "fill", backgroundColor = "#F5F5F5",
        {
            LinearLayout, orientation = 0, layout_width = "fill", padding = "16dp", gravity = 16, backgroundColor = "#1565C0",
            { TextView, text = "Acerca de", textSize = "20sp", textColor = "#FFFFFF", layout_weight = 1 },
            { Button, id = "btnBack", text = "Navegar hacia arriba", backgroundColor = "#0D47A1", textColor = "#FFFFFF", layout_marginLeft = "8dp" }
        },
        {
            ScrollView, layout_width = "fill", layout_weight = 1,
            {
                LinearLayout, orientation = 1, padding = "16dp", layout_width = "fill",
                { TextView, text = "Funcionamiento", textSize = "18sp", textColor = "#1565C0", paddingBottom = "8dp" },
                { TextView, text = "Desarrollado por Visión Accesible Company.\n\nEste complemento automatiza la limpieza de memoria caché de tus aplicaciones para optimizar tu dispositivo.", textSize = "16sp", textColor = "#424242", paddingBottom = "16dp" },
                { TextView, text = "Guía de uso:", textSize = "16sp", textColor = "#1565C0", paddingBottom = "8dp" },
                { TextView, text = "1. Toque simple: Limpia la caché de una sola aplicación al instante.", textSize = "15sp", textColor = "#424242", paddingBottom = "8dp" },
                { TextView, text = "2. Pulsación larga: Activa la selección múltiple. En la parte inferior aparecerá el botón 'Seleccionar todo'.", textSize = "15sp", textColor = "#424242", paddingBottom = "8dp" },
                { TextView, text = "3. Más opciones: Filtra la lista para mostrar solo aplicaciones de usuario, del sistema o todas.", textSize = "15sp", textColor = "#424242", paddingBottom = "8dp" },
                { TextView, text = "4. Limpiar: Realizará la limpieza a todo lo seleccionado automáticamente y te devolverá a la pantalla de inicio al terminar. IMPORTANTE: No interrumpas el funcionamiento moviendo el lector de pantalla para que el complemento trabaje correctamente.", textSize = "15sp", textColor = "#424242", paddingBottom = "24dp" },
                { TextView, text = "Comunidad y Contacto", textSize = "18sp", textColor = "#1565C0", paddingBottom = "8dp" },
                { TextView, text = "Para dudas, sugerencias, reporte de errores o para adquirir más complementos, únete a nuestras plataformas:", textSize = "16sp", textColor = "#424242", paddingBottom = "16dp" },
                { Button, id = "btnTelegram", text = "Telegram", backgroundColor = "#0088CC", textColor = "#FFFFFF", layout_marginBottom = "8dp" },
                { Button, id = "btnWhatsApp", text = "WhatsApp", backgroundColor = "#25D366", textColor = "#FFFFFF", layout_marginBottom = "8dp" },
                { Button, id = "btnYouTube", text = "YouTube", backgroundColor = "#FF0000", textColor = "#FFFFFF", layout_marginBottom = "16dp" }
            }
        }
    }
    local dlgAbout = LuaDialog(context)
    dlgAbout.setView(loadlayout(aboutLayout))
    dlgAbout.show()
    btnBack.onClick = function() dlgAbout.dismiss() end
    btnTelegram.onClick = function()
        dlgAbout.dismiss()
        if mainDlg then mainDlg.dismiss() end
        reproducirSonido("Open link.mp3")
        service.asyncSpeak("Abriendo Telegram.")
        openUrl("https://t.me/elcanaloficial")
    end
    btnWhatsApp.onClick = function()
        dlgAbout.dismiss()
        if mainDlg then mainDlg.dismiss() end
        reproducirSonido("Open link.mp3")
        service.asyncSpeak("Abriendo WhatsApp.")
        openUrl("https://chat.whatsapp.com/LF2AgNhv1ETFgqKNS2wSkz")
    end
    btnYouTube.onClick = function()
        dlgAbout.dismiss()
        if mainDlg then mainDlg.dismiss() end
        reproducirSonido("Open link.mp3")
        service.asyncSpeak("Abriendo YouTube.")
        openUrl("https://youtube.com/@vision_accesible?si=iYeAHZI5Xq1L0rtX")
    end
end

function M.showUI()
    local layout = {
        LinearLayout, orientation = 1, layout_width = "fill", layout_height = "fill", backgroundColor = "#F5F5F5",
        {
            LinearLayout, orientation = 0, layout_width = "fill", padding = "16dp", gravity = 16, backgroundColor = "#1565C0",
            {
                LinearLayout, orientation = 1, layout_weight = 1,
                { TextView, text = "Auto Limpiador Vanguard", textSize = "18sp", textColor = "#4DD0E1" },
                { TextView, text = "Visión accesible", textSize = "14sp", textColor = "#B2EBF2", paddingTop = "2dp" }
            },
            { Button, id = "btnAboutMenu", text = "Acerca de", backgroundColor = "#0D47A1", textColor = "#FFFFFF", layout_marginRight = "8dp" },
            { Button, id = "btnFilter", text = "Más opciones", backgroundColor = "#0D47A1", textColor = "#FFFFFF" }
        },
        { TextView, id = "loadingText", text = "Escaneando aplicaciones...", textSize = "16sp", textColor = "#424242", padding = "12dp" },
        { ListView, id = "appList", layout_width = "fill", layout_weight = 1, backgroundColor = "#FFFFFF" },
        {
            LinearLayout, id = "bottomBar", orientation = 0, layout_width = "fill", padding = "8dp", visibility = 8, backgroundColor = "#E0E0E0",
            { Button, id = "btnSelectAll", text = "Seleccionar todo", layout_weight = 1, backgroundColor = "#1976D2", textColor = "#FFFFFF" },
            { Button, id = "btnCleanSelected", text = "Limpiar", layout_weight = 1, backgroundColor = "#2E7D32", textColor = "#FFFFFF" },
            { Button, id = "btnCancelSelection", text = "Cancelar", layout_weight = 1, backgroundColor = "#C62828", textColor = "#FFFFFF" }
        }
    }
    local dlg = LuaDialog(context)
    dlg.setView(loadlayout(layout))
    dlg.setNegativeButton("Cerrar", nil)
    dlg.setOnDismissListener(luajava.createProxy("android.content.DialogInterface$OnDismissListener", {
        onDismiss = function(dialog) detenerBucle() end
    }))
    dlg.show()
    reproducirSonido("Interface.mp3")

    -- 🌐 COMPROBACIÓN OTA SILENCIOSA
    checkUpdate()

    local allAppsData = {}
    local filteredAppsData = {}
    local javaList = ArrayList()
    local ArrayAdapter = luajava.bindClass("android.widget.ArrayAdapter")
    local adapter
    local mode = "SINGLE"
    local allSelected = false

    local function toggleSelectionMode(enable)
        mode = enable and "MULTI" or "SINGLE"
        local layoutId = enable and android.R.layout.simple_list_item_multiple_choice or android.R.layout.simple_list_item_1
        adapter = ArrayAdapter(context, layoutId, javaList)
        appList.setAdapter(adapter)
        appList.setChoiceMode(enable and 2 or 0)
        bottomBar.setVisibility(enable and 0 or 8)
    end

    local function applyFilter(filterType)
        filteredAppsData = {}
        javaList.clear()
        for _, app in ipairs(allAppsData) do
            local isSystem = (app.flags % 2 ~= 0)
            if filterType == "ALL" or (filterType == "USER" and not isSystem) or (filterType == "SYSTEM" and isSystem) then
                table.insert(filteredAppsData, app)
                javaList.add(app.name .. "\n(" .. app.pkg .. ")")
            end
        end
        toggleSelectionMode(mode == "MULTI")
        loadingText.setText("Mostrando " .. #filteredAppsData .. " aplicaciones")
    end

    btnAboutMenu.onClick = function()
        reproducirSonido("About.mp3")
        showAboutUI(dlg)
    end
    btnCancelSelection.onClick = function()
        reproducirSonido("Cancel selection.mp3")
        toggleSelectionMode(false)
    end
    btnSelectAll.onClick = function()
        allSelected = not allSelected
        for i = 0, javaList.size() - 1 do
            appList.setItemChecked(i, allSelected)
        end
        if allSelected then
            btnSelectAll.setText("Desmarcar todo")
        else
            btnSelectAll.setText("Seleccionar todo")
        end
    end
    btnCleanSelected.onClick = function()
        queue = {}
        local checked = appList.getCheckedItemPositions()
        for i = 0, javaList.size() - 1 do
            if checked and checked.get(i) then
                table.insert(queue, filteredAppsData[i + 1])
            end
        end
        if #queue > 0 then
            dlg.dismiss()
            service.asyncSpeak("Iniciando limpieza de " .. #queue .. " aplicaciones.")
            processQueue()
        else
            service.asyncSpeak("No hay aplicaciones seleccionadas.")
        end
    end
    btnFilter.onClick = function(v)
        reproducirSonido("Open more options.mp3")
        local PopupMenu = luajava.bindClass("android.widget.PopupMenu")
        local popup = PopupMenu(context, v)
        local menu = popup.getMenu()
        menu.add("Todas las aplicaciones")
        menu.add("Aplicaciones del usuario")
        menu.add("Aplicaciones del sistema")
        popup.setOnMenuItemClickListener(luajava.createProxy("android.widget.PopupMenu$OnMenuItemClickListener", {
            onMenuItemClick = function(item)
                local title = tostring(item.getTitle())
                if title == "Todas las aplicaciones" then applyFilter("ALL")
                elseif title == "Aplicaciones del usuario" then applyFilter("USER")
                elseif title == "Aplicaciones del sistema" then applyFilter("SYSTEM") end
                service.asyncSpeak("Filtro aplicado.")
                return true
            end
        }))
        popup.show()
    end

    iniciarBucle("Scan.mp3")
    AsyncTask.execute(luajava.createProxy("java.lang.Runnable", {
        run = function()
            local pm = context.getPackageManager()
            local packages = pm.getInstalledApplications(0)
            if packages then
                for i = 0, packages.size() - 1 do
                    local pkgInfo = packages.get(i)
                    local pkgName = pkgInfo.packageName
                    local appName = tostring(pm.getApplicationLabel(pkgInfo) or pkgName)
                    table.insert(allAppsData, {name = appName, pkg = pkgName, flags = pkgInfo.flags})
                end
            end
            table.sort(allAppsData, function(a, b) return a.name:lower() < b.name:lower() end)
            runOnUiThread(function()
                detenerBucle()
                applyFilter("ALL")
                reproducirSonido("Loaded.mp3")
            end)
        end
    }))

    appList.setOnItemClickListener(luajava.createProxy("android.widget.AdapterView$OnItemClickListener", {
        onItemClick = function(parent, view, position, id)
            if mode == "SINGLE" then
                local selectedApp = filteredAppsData[position + 1]
                if selectedApp then
                    dlg.dismiss()
                    queue = {selectedApp}
                    service.asyncSpeak("Iniciando tarea única.")
                    processQueue()
                end
            end
        end
    }))

    appList.setOnItemLongClickListener(luajava.createProxy("android.widget.AdapterView$OnItemLongClickListener", {
        onItemLongClick = function(parent, view, position, id)
            if mode == "SINGLE" then
                reproducirSonido("Start selection.mp3")
                toggleSelectionMode(true)
                appList.setItemChecked(position, true)
                service.asyncSpeak("Modo de selección múltiple activado.")
            end
            return true
        end
    }))
end

return M
]]

local finalCode = code
local obfuscatedCode, errObf = ofuscar(code)
if obfuscatedCode then
    finalCode = obfuscatedCode
else
    print("Nota: El código se guardará sin ofuscar. Error: " .. tostring(errObf))
end

local f = io.open(modulePath, "wb")
if f then
    f:write(finalCode)
    f:close()
else
    service.asyncSpeak("Error crítico al crear auto_cleaner.lua")
    return true
end

package.loaded[moduleName] = nil
local success, cleaner = pcall(require, moduleName)
if success and cleaner and cleaner.showUI then
    cleaner.showUI()
else
    service.asyncSpeak("Error al arrancar el módulo ofuscado.")
end

return true
